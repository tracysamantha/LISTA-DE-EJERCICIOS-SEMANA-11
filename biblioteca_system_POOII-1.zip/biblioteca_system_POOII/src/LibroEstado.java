public enum LibroEstado {
    OCUPADO, LIBRE, NO_EXISTE
}
