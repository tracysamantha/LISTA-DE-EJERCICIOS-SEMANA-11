public class Libro {

    protected String titulo;
    protected String autor;
    protected String anioPub;
    protected String genero;
    protected String numeroPag;
    protected String estadoPres;
    protected String nroCap;
    protected String fechaLib;


    public Libro(String titulo, String autor, String anioPub, String genero, String numeroPag, String estadoPres, String nroCap, String fechaLib) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPub = anioPub;
        this.genero = genero;
        this.numeroPag = numeroPag;
        this.estadoPres = estadoPres;
        this.nroCap = nroCap;
        this.fechaLib = fechaLib;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getFechaLib() {
        return fechaLib;
    }

    public String getNroCap() {
        return nroCap;
    }

    public String getEstadoPres() {
        return estadoPres;
    }

    public String getNumeroPag() {
        return numeroPag;
    }

    public String getGenero() {
        return genero;
    }

    public String getAnioPub() {
        return anioPub;
    }

    public String getAutor() {
        return autor;
    }
}
