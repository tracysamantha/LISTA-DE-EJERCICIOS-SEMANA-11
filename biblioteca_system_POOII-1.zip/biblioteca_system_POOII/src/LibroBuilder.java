public class LibroBuilder implements Builder{
    private String titulo;
    private String autor;
    private String anioPub;
    private String genero;
    private String numPag;
    private String estadoPres;
    private String nroCap;
    private String fechaLib;

    @Override
    public void setTitulo(String titulo) {

    }

    @Override
    public void setAutor(String autor) {

    }

    @Override
    public void setAnioPub(String anioPub) {

    }

    @Override
    public void setGenero(String genero) {

    }

    @Override
    public void setNumeroPag(String numPag) {

    }

    @Override
    public void setEstadoPrestado(String estadoPres) {

    }

    @Override
    public void setNroCap(String nroCap) {

    }

    @Override
    public void setFechaLiberacion(String fechaLib) {

    }

    public Libro getResult(){
        return new Libro(titulo, autor, anioPub, genero, numPag, estadoPres, nroCap, fechaLib);
    }
}
