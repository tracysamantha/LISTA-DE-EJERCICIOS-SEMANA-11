
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 *
 * @author Sofía
 */
public class AplicarRepository implements LibroRepository {
    
    private final String archivo = "./src/libros.txt";

    @Override
    public void guardar(Libro libro) {
        try (BufferedWriter BW = new BufferedWriter(new FileWriter(archivo, true))) {
            BW.write(libro.toString());
            BW.newLine();
            System.out.println("Libro guardado: " + libro);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Libro buscarPorAutor(String autor) {
        Function<List<Integer>, List<Integer>> LibroAutor = l -> l.stream().filter(l->l.g).collect(Collectors.toList());
    }

    @Override
    public Libro buscarPorGenero(String genero) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Libro> obtenerTodosLosLibros() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void actualizar(Libro libro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminar(String titulo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
