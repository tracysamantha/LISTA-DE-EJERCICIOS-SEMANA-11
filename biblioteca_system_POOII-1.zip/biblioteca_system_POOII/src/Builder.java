public interface Builder {
    void setTitulo(String titulo);
    void setAutor(String autor);
    void setAnioPub(String anioPub);
    void setGenero(String genero);
    void setNumeroPag(String numPag);
    void setEstadoPrestado(String estadoPres);
    void setNroCap(String nroCap);
    void setFechaLiberacion(String fechaLib);
}
