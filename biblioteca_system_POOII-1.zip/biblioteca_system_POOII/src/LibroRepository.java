import java.util.List;

/**
 *
 * @author Sofía
 */
public interface LibroRepository {
    void guardar(Libro libro);
    Libro buscarPorAutor(String autor);
    Libro buscarPorGenero(String genero);
    List<Libro> obtenerTodosLosLibros();
    void actualizar(Libro libro);
    void eliminar(String titulo);
}
