/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tracy
 */
public class GestorLibreria {
    private List<Libro> libros;

    public GestorLibreria() {
        libros = new ArrayList<>();
    }

    public void cargarLibrosDesdeArchivo(String archivoRuta) {
        try (BufferedReader br = new BufferedReader(new FileReader(archivoRuta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split("\\|");
                if (datos.length == 6) { 
                    Libro libro = new Libro.Builder(datos[0], datos[1]) 
                            .anoPublicacion(Integer.parseInt(datos[2]))
                            .genero(datos[3])
                            .numeroPaginas(Integer.parseInt(datos[4]))
                            .estadoPrestamo(datos[5]) 
                            .build();
                    libros.add(libro);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    public void agregarLibro(Libro libro) {
        libros.add(libro);
        System.out.println("Libro añadido: " + libro.getTitulo());
    }

    public List<Libro> listarLibros() {
        return libros;
    }
}


