/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;

import java.util.List;
import java.util.Scanner;

/**
 *
 * @author tracy
 */
public class Main {

    public static void main(String[] args) {
        GestorLibreria gestorLibreria = new GestorLibreria();
        GestorNotificaciones gestorNotificaciones = new GestorNotificaciones();

        // Aqui se cargan libros desde el txt
        String archivoRuta = "ruta";
        gestorLibreria.cargarLibrosDesdeArchivo(archivoRuta);

        // Crear Observadores (Usuarios)
        Observer observador1 = new Observer("Tracy", "tracyhuaman@email.com", "234 567 890");
        Observer observador2 = new Observer("Lia", "liahumareda@email.com", "123456789");

        // Inicializar el menú interactivo
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\n--- Menú del Sistema de Biblioteca ---");
            System.out.println("1) Ver lista de libros");
            System.out.println("2) Suscribirse a un libro");
            System.out.println("3) Recibir notificaciones del estado de un libro");
            System.out.println("4) Realizar otras suscripciones");
            System.out.println("5) Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer

            switch (opcion) {
                case 1:
                    mostrarListaLibros(gestorLibreria.listarLibros());
                    break;
                case 2:
                    suscribirseALibro(gestorLibreria, gestorNotificaciones, scanner, observador1);
                    break;
                case 3:
                    suscribirseANotificacionesDeEstado(gestorNotificaciones, scanner, observador1);
                    break;
                case 4:
                    realizarOtrasSuscripciones(gestorNotificaciones, scanner, observador1);
                    break;
                case 5:
                    salir = true;
                    System.out.println("Se ha cerrado sesion en el sistema");
                    break;
                default:
                    System.out.println("ERROR en el sistema");
            }
        }

        scanner.close();
    }

    private static void mostrarListaLibros(List<Libro> libros) {
        System.out.println("\n--- Lista de Libros Disponibles ---");
        for (int i = 0; i < libros.size(); i++) {
            Libro libro = libros.get(i);
            System.out.println((i + 1) + ". " + libro.getTitulo() + " - " + libro.getAutor());
        }
    }

    private static void suscribirseALibro(GestorLibreria gestorLibreria, GestorNotificaciones gestorNotificaciones, Scanner scanner, Observer observador) {
        List<Libro> libros = gestorLibreria.listarLibros();
        mostrarListaLibros(libros);

        System.out.print("Seleccione el número del libro al que desea suscribirse: ");
        int libroIndex = scanner.nextInt() - 1;
        scanner.nextLine();  // Limpiar el buffer

        if (libroIndex >= 0 && libroIndex < libros.size()) {
            Libro libroSeleccionado = libros.get(libroIndex);
            observador.agregarLibroPreferido(libroSeleccionado.getTitulo());
            gestorNotificaciones.suscribirObserver("Disponibilidad del libro: " + libroSeleccionado.getTitulo(), observador);
            System.out.println("Se ha suscrito a las notificaciones de disponibilidad del libro: " + libroSeleccionado.getTitulo());
        } else {
            System.out.println("Número de libro no válido.");
        }
    }

    private static void suscribirseANotificacionesDeEstado(GestorNotificaciones gestorNotificaciones, Scanner scanner, Observer observador) {
        System.out.print("Ingrese el nombre del libro para recibir notificaciones de estado: ");
        String nombreLibro = scanner.nextLine();
        gestorNotificaciones.suscribirObserver("Estado del libro: " + nombreLibro, observador);
        System.out.println("Se ha suscrito a las notificaciones del estado del libro: " + nombreLibro);
    }

    private static void realizarOtrasSuscripciones(GestorNotificaciones gestorNotificaciones, Scanner scanner, Observer observador) {
        System.out.print("Ingrese el tipo de notificación al que desea suscribirse: ");
        String tipoNotificacion = scanner.nextLine();
        gestorNotificaciones.suscribirObserver(tipoNotificacion, observador);
        System.out.println("Se ha suscrito a las notificaciones de: " + tipoNotificacion);
    }
}
